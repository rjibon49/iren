"use strict";
(() => {
var exports = {};
exports.id = 91;
exports.ids = [91];
exports.modules = {

/***/ 3320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ contact)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
;// CONCATENATED MODULE: ./config/nodeMailer.js

const email = process.env.EMAIL;
const pass = process.env.EMAIL_PASS;
const transporter = external_nodemailer_default().createTransport({
    service: "gmail",
    auth: {
        user: email,
        pass
    }
});
const mailOptions = {
    from: email,
    to: email
};

;// CONCATENATED MODULE: external "multer"
const external_multer_namespaceObject = require("multer");
var external_multer_default = /*#__PURE__*/__webpack_require__.n(external_multer_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/contact.js
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction


const CONTACT_MESSAGE_FIELDS = {
    name: "name",
    email: "email",
    number: "number",
    subject: "subject",
    budget: "budget",
    message: "message"
};
const generateEmailContent = (data)=>{
    const stringData = Object.entries(data).reduce((str, [key, val])=>str += `${CONTACT_MESSAGE_FIELDS[key]}: ${val} \n \n`, "");
    const htmlData = Object.entries(data).reduce((str, [key, val])=>str += `<p className="mailTextTitle" align="left">${CONTACT_MESSAGE_FIELDS[key]}: <span style="color:red; font-size:16px;"> ${val} </span></p>`, "");
    return {
        text: stringData,
        html: htmlData
    };
};
const storage = external_multer_default().memoryStorage();
const upload = external_multer_default()({
    storage: storage
});
const handler = async (req, res)=>{
    try {
        if (req.method === "POST") {
            // Use upload middleware to handle file uploads
            upload.array("attachment")(req, res, async function(err) {
                if (err) {
                    return res.status(400).json({
                        message: err.message
                    });
                }
                const data = req.body;
                // If you have a file input in your form, you can access the file information from req.files
                const attachments = (req.files || []).map((file)=>({
                        filename: file.originalname,
                        content: file.buffer
                    }));
                await transporter.sendMail({
                    ...mailOptions,
                    ...generateEmailContent(data),
                    subject: data.subject,
                    attachments
                });
                return res.status(200).json({
                    success: true
                });
            });
        } else {
            return res.status(400).json({
                message: "Bad request"
            });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            message: "Internal server error"
        });
    }
};
const config = {
    api: {
        bodyParser: false
    }
};
/* harmony default export */ const contact = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3320));
module.exports = __webpack_exports__;

})();